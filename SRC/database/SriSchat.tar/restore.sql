--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.24
-- Dumped by pg_dump version 9.6.24

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP RULE "MessageEvent" ON public.group_messages;
DROP RULE "MessageEvent" ON public.messages;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.messages DROP CONSTRAINT messages_pkey;
ALTER TABLE ONLY public.groups DROP CONSTRAINT groups_pkey;
ALTER TABLE ONLY public.group_messages DROP CONSTRAINT group_messages_pkey;
ALTER TABLE ONLY public.books DROP CONSTRAINT books_pkey;
ALTER TABLE public.books ALTER COLUMN id DROP DEFAULT;
DROP TABLE public.users;
DROP TABLE public.messages;
DROP TABLE public.groups;
DROP TABLE public.group_messages;
DROP SEQUENCE public.books_id_seq;
DROP TABLE public.books;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: DATABASE "Schat"; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE "Schat" IS 'for schat qt application
';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: books; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.books (
    id integer NOT NULL,
    title character varying(100) NOT NULL,
    primary_author character varying(100)
);


ALTER TABLE public.books OWNER TO postgres;

--
-- Name: books_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.books_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.books_id_seq OWNER TO postgres;

--
-- Name: books_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.books_id_seq OWNED BY public.books.id;


--
-- Name: group_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.group_messages (
    id integer DEFAULT nextval('public.books_id_seq'::regclass) NOT NULL,
    message character varying(255) NOT NULL,
    group_id integer NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    "timestamp" timestamp(6) with time zone DEFAULT '2021-12-29 18:44:35.975162+05:30'::timestamp with time zone NOT NULL,
    sender_id integer NOT NULL
);


ALTER TABLE public.group_messages OWNER TO postgres;

--
-- Name: groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.groups (
    id integer DEFAULT nextval('public.books_id_seq'::regclass) NOT NULL,
    group_name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    participants character varying(255) NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    "timestamp" timestamp(6) with time zone DEFAULT '2021-12-29 18:36:26.358841+05:30'::timestamp with time zone NOT NULL
);


ALTER TABLE public.groups OWNER TO postgres;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    id integer DEFAULT nextval('public.books_id_seq'::regclass) NOT NULL,
    message text NOT NULL,
    sender_id integer NOT NULL,
    reciever_id integer NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    "timestamp" time(6) with time zone DEFAULT '11:23:32.06066+05:30'::time with time zone NOT NULL
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer DEFAULT nextval('public.books_id_seq'::regclass) NOT NULL,
    username character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    firstname character varying(255) NOT NULL,
    lastname character varying NOT NULL,
    contactno character varying(255) NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    "timestamp" timestamp(6) with time zone DEFAULT '2021-12-28 18:30:59.041391+05:30'::timestamp with time zone NOT NULL,
    profile_pic bytea
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: books id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books ALTER COLUMN id SET DEFAULT nextval('public.books_id_seq'::regclass);


--
-- Data for Name: books; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.books (id, title, primary_author) FROM stdin;
\.
COPY public.books (id, title, primary_author) FROM '$$PATH$$/2163.dat';

--
-- Name: books_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.books_id_seq', 334, true);


--
-- Data for Name: group_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.group_messages (id, message, group_id, status, "timestamp", sender_id) FROM stdin;
\.
COPY public.group_messages (id, message, group_id, status, "timestamp", sender_id) FROM '$$PATH$$/2167.dat';

--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.groups (id, group_name, description, participants, status, "timestamp") FROM stdin;
\.
COPY public.groups (id, group_name, description, participants, status, "timestamp") FROM '$$PATH$$/2166.dat';

--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (id, message, sender_id, reciever_id, status, "timestamp") FROM stdin;
\.
COPY public.messages (id, message, sender_id, reciever_id, status, "timestamp") FROM '$$PATH$$/2165.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password, firstname, lastname, contactno, status, "timestamp", profile_pic) FROM stdin;
\.
COPY public.users (id, username, password, firstname, lastname, contactno, status, "timestamp", profile_pic) FROM '$$PATH$$/2164.dat';

--
-- Name: books books_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT books_pkey PRIMARY KEY (id);


--
-- Name: group_messages group_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_messages
    ADD CONSTRAINT group_messages_pkey PRIMARY KEY (id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: messages MessageEvent; Type: RULE; Schema: public; Owner: postgres
--

CREATE RULE "MessageEvent" AS
    ON INSERT TO public.messages DO
 NOTIFY msg;
ALTER TABLE public.messages ENABLE ALWAYS RULE "MessageEvent";


--
-- Name: group_messages MessageEvent; Type: RULE; Schema: public; Owner: postgres
--

CREATE RULE "MessageEvent" AS
    ON INSERT TO public.group_messages DO
 NOTIFY msg;


--
-- PostgreSQL database dump complete
--

